package com.geekcap.vmturbo;

public class Thing {
  private int n = 0;

  public int getN() {
    return n;
  }

  public void setN(int n) {
    this.n = n;
  }
}
